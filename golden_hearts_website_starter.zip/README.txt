GOLDEN HEARTS WEBSITE STARTER

Files:
- index.html: responsive website template

Before publishing:
1. Replace "Golden Hearts" if you choose another name.
2. Replace hello@example.com in the HTML and JavaScript with your real email address.
3. Replace the sample location with your real location.
4. Replace sample dog profiles, ages, availability, and photos with accurate, authorized information.
5. The inquiry form opens the visitor's email app; it does not store or automatically submit form data. For a true online form, connect a form service or backend.

Quick publish option:
- Create a GitHub account at https://github.com
- Create a new public repository
- Upload index.html to the repository root
- Open repository Settings > Pages
- Choose deployment from the main branch and save
- Follow GitHub's instructions to visit your published site
- For a custom domain, buy one from a domain registrar and connect it in Settings > Pages.

Alternative hosting: Cloudflare Pages supports static websites and custom domains.
